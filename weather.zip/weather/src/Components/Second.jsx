import { Box, Flex, Text, Heading, Image, Button } from "@chakra-ui/react";
import React from "react";

const Second = () => {
  const hours = [
    {
      time: "12:00 AM",
      temperature: "30°",
      weatherIcon: "sunny",
      percentage: "10%",
    },
    {
      time: "01:00 AM",
      temperature: "28°",
      weatherIcon: "cloudy",
      percentage: "15%",
    },
    {
      time: "02:00 AM",
      temperature: "26°",
      weatherIcon: "rainy",
      percentage: "25%",
    },
    {
      time: "03:00 AM",
      temperature: "24°",
      weatherIcon: "sunny",
      percentage: "30%",
    },
    {
      time: "04:00 AM",
      temperature: "22°",
      weatherIcon: "rainy",
      percentage: "40%",
    },
    {
      time: "05:00 AM",
      temperature: "20°",
      weatherIcon: "cloudy",
      percentage: "50%",
    },
    {
      time: "06:00 AM",
      temperature: "18°",
      weatherIcon: "sunny",
      percentage: "60%",
    },
    {
      time: "07:00 AM",
      temperature: "16°",
      weatherIcon: "sunny",
      percentage: "70%",
    },
  ];

  return (
    <>
      {" "}
      <Box
        // h="95vh"
        width="75%"
        borderRadius="40px"
        bg="rgb(227,241,255)"
        left="25%"
        position="relative"
        p={4}
        // border="1px solid red"
      >
        <Box p={2}>
          <Flex justifyContent="space-between" alignItems="center">
            <Box>
              <Heading fontFamily="body" fontWeight="medium">
                Welcome back Isabella!
              </Heading>
              <Text
                mt="0.5rem"
                fontFamily="body"
                fontSize="xl"
                fontWeight={500}
              >
                Check out today's weather information
              </Text>
            </Box>
            <Flex alignItems="center" gap="20px">
              <span class="material-symbols-outlined">more_horiz</span>
              <Image
                // src={profilePic}
                src="https://srcwap.com/wp-content/uploads/2022/08/empty-profile-hd-png-download.jpg"
                alt="Profile Picture"
                boxSize={10}
                borderRadius="10px"
              />
            </Flex>
          </Flex>

          <Box bg="rgb(255,255,255)" borderRadius="20px" mt="2rem">
            <Box p={4}>
              <Flex justifyContent="space-between">
                <Text fontFamily="body" fontSize="xl" fontWeight={500}>
                  Upcoming hours
                </Text>
                <Box>
                  <Flex gap="20px">
                    <Button
                      borderRadius="15px"
                      borderColor="gray.500"
                      fontWeight="medium"
                      color="gray.500"
                    >
                      Rain precipitation
                      <Text ml={2} className="material-symbols-outlined">
                        keyboard_arrow_down
                      </Text>
                    </Button>
                    <Button
                      borderRadius="15px"
                      borderColor="gray.500"
                      fontWeight={700}
                    >
                      Next days
                      <span class="material-symbols-outlined">
                        navigate_next
                      </span>
                    </Button>
                  </Flex>
                </Box>
              </Flex>
            </Box>
            <Flex justify="center" align="center" padding="1rem" gap="10px">
              {hours.map((hour) => (
                <Box
                  border="1px solid gray"
                  key={hour.time}
                  w="12%"
                  _hover={{
                    boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
                    cursor: "pointer",
                    border: "none",
                  }}
                  p={4}
                  borderRadius="md"
                  textAlign="center"
                >
                  <Text>{hour.time}</Text>
                  <Text
                    mt="5px"
                    fontSize="2xl"
                    className={`material-symbols-outlined ${hour.weatherIcon}`}
                  >
                    {hour.weatherIcon}
                  </Text>
                  <Text fontSize="lg">{hour.temperature}</Text>
                  <Text>{hour.percentage}</Text>
                </Box>
              ))}
            </Flex>
          </Box>
        </Box>
        <Text fontFamily="body" fontSize="2xl" fontWeight={600}>
          More details of today's weather
        </Text>
        <Box
          display="grid"
          gridTemplateColumns="repeat(3, 1fr)"
          gridGap="10px"
          justifyContent="center"
          alignItems="center"
          padding="0.5rem"
          // border="1px solid black"
        >
          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                Humidity
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">humidity_low</span>
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="50%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>82%</Heading>
                <Text textAlign="center" mt={2} fontSize={20}>
                  bad
                </Text>
              </Flex>
            </Box>
            <Box marginRight="15px" color="gray.400">
              <Flex justifyContent="space-evenly">
                <Box>
                  <Text>good</Text>
                  <Text
                    mt="5px"
                    w="160%"
                    h="10px"
                    bg="rgb(92,156,229)"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>normal</Text>{" "}
                  <Text
                    mt="5px"
                    w="130%"
                    h="10px"
                    bg="rgb(92,156,229)"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>bad</Text>
                  <Text
                    mt="5px"
                    w="230%"
                    h="10px"
                    bgGradient={`linear(to-r, rgb(92,156,229) 50%, gray.300 50%)`}
                    borderRadius="md"
                  ></Text>
                </Box>
              </Flex>
            </Box>
          </Box>
          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                Wind
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">air</span>
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="60%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>82 km/h</Heading>
              </Flex>
            </Box>
            <Box marginRight="15px" color="gray.400" margin="auto">
              <Flex justifyContent="space-between">
                <Box>
                  <Text>0</Text>
                </Box>

                <Box>
                  <Text>20</Text>
                </Box>

                <Box>
                  <Text>40</Text>
                </Box>

                <Box>
                  <Text>60</Text>
                </Box>

                <Box>
                  <Text>80</Text>
                </Box>
                <Box>
                  <Text>100</Text>
                </Box>
              </Flex>

              <Text
                mt="5px"
                w="100%"
                h="10px"
                bg="gray.300"
                bgGradient={`linear(to-r, rgb(92,156,229) 80%, gray.300 20%)`}
                borderRadius="20px"
              ></Text>
            </Box>
          </Box>

          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                Precipitation
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">rainy</span>{" "}
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="50%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>1.4 cm</Heading>
              </Flex>
            </Box>
            <Box marginRight="15px" color="gray.400" margin="auto">
              <Flex justifyContent="space-between">
                <Box>
                  <Text>0</Text>
                  <Text
                    mt="5px"
                    w="170%"
                    h="10px"
                    bg="rgb(92,156,229)"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>10</Text>{" "}
                  <Text
                    mt="5px"
                    w="110%"
                    h="10px"
                    bgGradient={`linear(to-r, rgb(92,156,229) 50%, gray.300 50%)`}
                    borderRadius="md"
                    ml="2px"
                  ></Text>
                </Box>
                <Box>
                  <Text>20</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    borderRadius="md"
                    bg="gray.300"
                    ml="2px"
                  ></Text>
                </Box>
                <Box>
                  <Text>30</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>40</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>50</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>60</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>70</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>80</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>90</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
              </Flex>
            </Box>
          </Box>

          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                UV index
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">light_mode</span>
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="50%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>4</Heading>
                <Text textAlign="center" mt={2} fontSize={20}>
                  medium
                </Text>
              </Flex>
            </Box>
            <Box marginRight="15px" color="gray.400">
              <Flex justifyContent="space-evenly">
                <Box>
                  <Text>0-2</Text>
                  <Text
                    mt="5px"
                    w="120%"
                    h="10px"
                    bg="rgb(92,156,229)"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>3-5</Text>{" "}
                  <Text
                    mt="5px"
                    w="130%"
                    h="10px"
                    bgGradient={`linear(to-r, rgb(92,156,229) 50%, gray.300 50%)`}
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>6-7</Text>
                  <Text
                    mt="5px"
                    w="130%"
                    h="10px"
                    borderRadius="md"
                    bg="gray.300"
                  ></Text>
                </Box>
                <Box>
                  <Text>8-10</Text>
                  <Text
                    mt="5px"
                    w="100%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
                <Box>
                  <Text>11+</Text>
                  <Text
                    mt="5px"
                    w="120%"
                    h="10px"
                    bg="gray.300"
                    borderRadius="md"
                  ></Text>
                </Box>
              </Flex>
            </Box>
          </Box>

          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                Feels like
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">device_thermostat</span>
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="20%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>30°</Heading>
              </Flex>
            </Box>
            <Box color="gray.400">
              <Flex justifyContent="space-around">
                <Box>
                  <Text>0°</Text>
                </Box>
                <Box>
                  <Text>25°</Text>{" "}
                </Box>
                <Box>
                  <Text>50°</Text>
                </Box>
              </Flex>
            </Box>
            <Text
              margin="auto"
              mt="5px"
              w="75%"
              h="10px"
              bgGradient={`linear(to-r, rgb(92,156,229) 70%, gray.300 30%)`}
              borderRadius="md"
            ></Text>
          </Box>

          <Box
            margin="auto"
            width="80%"
            borderRadius="30px"
            padding={4}
            bg="white"
          >
            <Flex justifyContent="space-between">
              <Text fontFamily="body" fontSize="16px" fontWeight={500}>
                Chance of rain
              </Text>
              <Box
                bg="rgb(92,156,229)"
                p="5px 5px 0px 5px"
                borderRadius={10}
                color="white"
              >
                <span class="material-symbols-outlined">beach_access</span>
              </Box>
            </Flex>
            <Box textAlign="center" margin="auto" w="30%">
              {" "}
              <Flex gap={2}>
                <Heading fontWeight={500}>42%</Heading>
              </Flex>
            </Box>
            <Box marginRight="15px" color="gray.400">
              <Flex justifyContent="space-evenly">
                <Box>
                  <Text>0%</Text>
                </Box>
                <Box>
                  <Text>25%</Text>{" "}
                </Box>
                <Box>
                  <Text>50%</Text>
                </Box>
                <Box>
                  <Text>75%</Text>
                </Box>
                <Box>
                  <Text>100%</Text>
                </Box>
              </Flex>
              <Text
                margin="auto"
                mt="5px"
                w="87%"
                h="10px"
                bgGradient={`linear(to-r, rgb(92,156,229) 50%, gray.300 50%)`}
                borderRadius="md"
              ></Text>
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default Second;
