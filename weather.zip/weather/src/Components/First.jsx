import { Box, Flex, Heading, Text } from "@chakra-ui/react";
import React from "react";

const First = () => {
  return (
    <Box
      // border="2px solid red"
      h="97vh"
      // h="100vh"
      width="33%"
      borderRadius="40px"
      position="absolute"
      bgImage="https://mcuoneclipse.files.wordpress.com/2014/02/162_6225.jpg"
    >
      <Box
        width="70%"
        // border="1px solid red"
        color="white"
        padding="1rem"
      >
        <Box mt="2.5rem">
          <Flex justify="space-evenly">
            <Box
              bg="white"
              color="rgb(92,156,229)"
              borderRadius="5px"
              height="24px"
            >
              {" "}
              <span class="material-symbols-outlined">add</span>
            </Box>

            <span class="material-symbols-outlined">steppers</span>
            <Flex gap="10px">
              <span>&#8451;</span>
              <Box>
                <span class="material-symbols-outlined">switches</span>
              </Box>
              <span>&#8457;</span>
            </Flex>
          </Flex>
        </Box>

        <Box
          // border="1px solid red"
          padding="1rem"
          marginTop="2rem"
          color="whiteAlpha.800"
        >
          <Flex justifyContent="space-between">
            <span class="material-symbols-outlined">near_me</span>
            <Text fontSize="18px" fontWeight={400} mr="1.5rem">
              New York, USA
            </Text>
            <Box p="0.2rem">
              <Flex gap="20px">
                <span class="material-symbols-outlined">wb_sunny</span>
                <Text fontSize="17px">07:19</Text>
              </Flex>
            </Box>
          </Flex>
          <Flex justifyContent="space-between" mt="1rem">
            <Text fontWeight={400}>Today 28 sept</Text>
            <Box p="0.2rem">
              <Flex gap="20px">
                <span class="material-symbols-outlined">wb_twilight</span>
                <Text fontSize="17px">19:32</Text>
              </Flex>
            </Box>
          </Flex>
        </Box>

        <Box mt="1rem" color="white">
          <Box p={4} margin="auto">
            <Flex align="center">
              <Text mr="1.5rem" className="material-symbols-outlined">
                arrow_back_ios
              </Text>

              <Heading
                textAlign="center"
                fontSize="7rem"
                fontWeight="normal"
                ml={9}
                mr={10}
              >
                25°
              </Heading>

              <span className="material-symbols-outlined">
                arrow_forward_ios
              </span>
            </Flex>
          </Box>
          <Box p={2}>
            <Flex
              align="center"
              justify="center"
              gap="10px"
              padding="0.5rem"
              mr="0.5rem"
            >
              <Text className="material-symbols-outlined">sunny</Text>
              <Text fontSize="3xl">Sunny</Text>
            </Flex>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default First;
