import React from "react";
import First from "./Components/First";
import Second from "./Components/Second";
import { Box, Flex } from "@chakra-ui/react";

const App = () => {
  return (
    <Box padding="2rem" width="95%" margin="auto">
      <Flex>
        <First />
        <Second />
      </Flex>
    </Box>
  );
};

export default App;
